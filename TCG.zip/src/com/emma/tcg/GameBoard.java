package com.emma.tcg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class GameBoard {
	Scanner sc = new Scanner(System.in);
	Statement st = null;
	ResultSet result = null;
	Connection con = null;
	ArrayList<Card> deck = new ArrayList<>();
	ArrayList<Card> playerdeck = new ArrayList<>();

	void run() {
		// DB연결
		dbInit();
		// DB저장된 카드덱 불러오기, 기본덱은 deck ArrayList에 / 플레이어 수정가능한 덱은 playerdeck에
		setDeck("card", deck);
		setDeck("customizedcard", playerdeck);

		// playerdeck.addAll(deck);

		System.out.println(
				"🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴TCG미니🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴🎴");
		loop_m: while (true) {
			System.out.println("[1]게임시작 / [2]덱설정 / [e]종료");
			System.out.print("명령입력 : ");
			String cmd = sc.next();

			switch (cmd) {
			case "1":// 컴퓨터전부터
				// 턴마다 드로우할 카드번호 셋팅
				int comHp = 20;
				int playerHp = 20;
				int comTrun = 0;
				int playerTrun = 0;
				int comCost = 0;
				int playerCost = 0;
				int[] comDraw = new int[30];
				int[] playerDraw = new int[30];
				Random r = new Random();
				for (int i = 0; i < 30; i++) {
					comDraw[i] = r.nextInt(30);
					playerDraw[i] = r.nextInt(30);
					for (int j = 0; j < i; j++) {
						if (comDraw[i] == comDraw[j] || playerDraw[i] == playerDraw[j])
							i--;
					}
				}
				// 컴퓨터,플레이어 핸드, 게임판을 배열로 구현
				Card[] comHand = new Card[8];
				Card[] playerHand = new Card[8];

				Card[] comBoard = new Card[3];
				Card[] playerBoard = new Card[3];

				// 게임시작 컴, 플레이어 첫드로우 (일단 선공은 플레이어 고정)
				for (int i = 0; i < 5; i++) {
					comHand[i] = deck.get(comDraw[i]);
					playerHand[i] = playerdeck.get(playerDraw[i]);
				}
				// 게임 루프
				loop_g: while (true) {
					comTrun++;
					playerTrun++;

					playerCost = playerTrun;
					int temp = 8;
					// 핸드에 빈자리 찾아서 거기에 카드 넣기 (밀어내서 정렬은 아직 미구현)
					for (int i = 0; i < 8; i++) {
						if (playerHand[i] == null) {
							temp = i;
							break;
						}
					}
					// 핸드가 꽉찼을 시 드로우 X
					if (temp == 8) {
						System.out.println("핸드가 꽉찼습니다. 드로우하지않고 버립니다.");
					} else {
						playerHand[temp] = playerdeck.get(playerDraw[playerTrun + 4]);
					}
					// 턴 루프
					loop_p: while (true) {
						// 필드내 내둔 카드가 있을시 공격가능상태로 변경
						for (int i = 0; i < 3; i++) {
							if (playerBoard[i] == null)
								continue;
							playerBoard[i].canAtt = true;
						}
						System.out.println("[1]카드 내기 / [2]핸드카드확인 / [3]필드내카드공격 / [e]턴종료 / [f]게임종료");
						System.out.print("명령입력 : ");
						cmd = sc.next();
						switch (cmd) {
						case "1":
							// 낼수있는카드가 있는지 체크(현재코스트보다 작거나 같은 카드가 있는지 확인)
							boolean canPlayCard = false;
							// playerHand에서 낼 수 있는 카드가 있는지 전체 검사
							for (int i = 0; i < playerHand.length; i++) {
								if (playerHand[i] != null && playerHand[i].cost <= playerCost
										&& playerHand[i].error == 0) {
									canPlayCard = true;
									break; // 낼 수 있는 카드가 있으면 반복문 종료
								}
							}
							// 만약 낼 수 있는 카드가 없다면 못낸다는 안내 sysout
							if (!canPlayCard) {
								System.out.println("낼 수 있는 카드가 없습니다.");
								break;
							}
							// 낼지 말지 여부 묻기
							System.out.print("카드를 내시겠습니까([1]내기 / [2] 넘기기) : ");
							cmd = sc.next();
							switch (cmd) {
							case "1":
								while (canPlayCard) {
									System.out.print("내실 카드의 번호를 입력해주세요 : ");
									int p = sc.nextInt();
									if (p <= 0 || p > 8) {
										System.out.println("잘못된 값입니다. 다시입력해주세요.");
										continue;
									}
									p -= 1;
									if (playerHand[p].cost > playerCost) {
										System.out.println("낼수있는 코스트를 초과했습니다. 다른카드를선택해주세요.");
										continue;
									}
									switch (playerHand[p].type) {
									case "1":
										while (true) {
											System.out.println("카드를 내실 위치를 번호로 입력해주세요 : ");
											int t = sc.nextInt();
											if (t <= 0 || t > 3) {
												System.out.println("잘못된 값입니다. 다시입력해주세요.");
												continue;
											}
											if (playerBoard[t] != null) {
												System.out.println("이미 카드가 있습니다. 다른 위치를 선택해주세요.");
												continue;
											}
											playerBoard[t] = playerHand[p];
											playerCost -= playerBoard[t].cost;
											break;
										}
										break;
									case "2":
										switch (playerHand[p].effect) {
										case "1":
											while (true) {
												System.out.println("효과대상의 위치를 번호로 입력해주세요(적본체는 0) : ");
												int t = sc.nextInt();
												if (t < 0 || t > 3) {
													System.out.println("잘못된 값입니다. 다시입력해주세요.");
													continue;
												}
												if (t == 0) {
													comHp -= playerHand[p].effect_dmg;
													if (comHp <= 0) {
														System.out.println("플레이어가 승리하였습니다.");
														break loop_g;
													}
													break;
												} else if (t > 0 && t <= 3) {
													t -= 1;
													comBoard[t].rDef -= playerHand[p].effect_dmg;
													if (comBoard[t].rDef <= 0)
														comBoard[t] = null;
													playerCost -= playerHand[p].cost;
													playerHand[p] = null;
													break;
												}
											}
											break;
										case "2":
											while (true) {
												System.out.println("효과대상의 위치를 번호로 입력해주세요(플레이어는 0) : ");
												int t = sc.nextInt();
												if (t < 0 || t > 3) {
													System.out.println("잘못된 값입니다. 다시입력해주세요.");
													continue;
												}
												if (t == 0) {
													playerHp += playerHand[p].effect_dmg;
													if (playerHp > 20)
														playerHp = 20;
													playerCost -= playerHand[p].cost;
													break;
												} else if (t > 0 && t <= 3) {
													t -= 1;
													playerBoard[t].rDef += playerHand[p].effect_dmg;
													if (playerBoard[t].rDef > playerBoard[t].def)
														playerBoard[t].rDef = playerHand[t].def;
													playerCost -= playerHand[p].cost;
													break;
												}
											}
											break;
										case "3":
											for (int i = 0; i < 3; i++) {
												if (playerBoard[i] == null)
													continue;
												playerBoard[i].rAtt += 1;
											}
											break;
										}
										break;
									}
									canPlayCard = false;
									for (int i = 0; i < playerHand.length; i++) {
										if (playerHand[i] != null && playerHand[i].cost <= playerCost
												&& playerHand[i].error == 0) {
											canPlayCard = true;
											break; // 낼 수 있는 카드가 있으면 반복문 종료
										}
									}
								}
							case "2":
								System.out.println("카드를 내지 않습니다.");
								break;
							}
						case "2":
							for (int i = 0; i < 8; i++) {
								if (playerHand[i] == null)
									continue;
								playerHand[i].CardInfo();
							}
							break;
						case "3":
							// 필드내 공격가능한 카드가 있는지 체크
							boolean canUseCard = false;
							// playerHand에서 낼 수 있는 카드가 있는지 전체 검사
							for (int i = 0; i < playerBoard.length; i++) {
								if (playerBoard[i] != null && playerBoard[i].canAtt == true) {
									canUseCard = true;
									break; // 낼 수 있는 카드가 있으면 반복문 종료
								}
							}
							// 만약 낼 수 있는 카드가 없다면 못낸다는 안내 sysout
							if (!canUseCard) {
								System.out.println("필드내 공격가능한 카드가 없습니다.");
								break;
							}
							while (true) {
								System.out.print("공격할 카드의 위치([1]/[2]/[3])(0번은 공격종료) : ");
								int att = sc.nextInt();
								if (att == 0) {
									System.out.println("공격을 종료합니다.");
									break;
								}
								if (att < 0 || att > 3) {
									System.out.println("잘못된 위치입니다. 다시입력하세요");
								}
								att -= 1;
								if (playerBoard[att] == null) {
									System.out.println((att + 1) + "번 필드에 카드가 없습니다.");
								}
								while (true) {
									System.out.println("공격할 대상의 위치를 번호로 입력해주세요(적본체는 0) : ");
									int t = sc.nextInt();
									if (t < 0 || t > 3) {
										System.out.println("잘못된 값입니다. 다시입력해주세요.");
										continue;
									}
									if (t == 0) {
										comHp -= playerBoard[att].rAtt;
										if (comHp <= 0) {
											System.out.println("플레이어가 승리하였습니다.");
											break loop_g;
										}
									} else {
										t -= 1;
										comBoard[t].rDef -= playerBoard[att].rAtt;
										if (comBoard[t].rDef <= 0)
											comBoard[t] = null;
										break;
									}
								}
							}

						case "e":
							System.out.println("턴종료");
							break loop_p;
						case "f":
							System.out.println("게임을 종료합니다.");
							break loop_g;
						}
					}

					// 컴퓨터턴
					// 컴퓨터 로직 1. 낼수있는 카드 있는지 확인 2. 카드내기(필드위치 대상 랜덤) 3. 필드내 카드 공격 수행
					comCost = comTrun;
					temp = 8;
					for (int i = 0; i < 8; i++) {
						if (comHand[i] == null) {
							temp = i;
							break;
						}
					}
					if (temp != 8) {
						comHand[temp] = deck.get(comDraw[comTrun + 4]);
					}
					loop_com: while (true) {
						// 낼 수 있는 카드가 있는지 확인하는 플래그
						boolean canPlayCard = false;

						// comHand에서 낼 수 있는 카드가 있는지 전체 검사
						for (int i = 0; i < comHand.length; i++) {
							if (comHand[i] != null && comHand[i].cost <= comCost && comHand[i].error == 0) {
								canPlayCard = true;
								break; // 낼 수 있는 카드가 있으면 반복문 종료
							}
						}

						// 만약 낼 수 있는 카드가 없다면 while 루프를 break
						if (!canPlayCard) {
							System.out.println("컴퓨터 턴 종료");
							for (int i = 0; i < 8; i++) {
								if (comHand[i] == null)
									continue;
								comHand[i].error = 0; // 기존에 넣었던 에러코드 초기화
							}
							break loop_com;
						}

						// 무작위 수 하나 추출(핸드최대범위(index 0~7) 한도내)
						int tempC = r.nextInt(8);
						if (comHand[tempC] != null && comHand[tempC].cost <= comCost && comHand[tempC].error == 0) {
							switch (comHand[tempC].type) {
							case "1": // 유닛카드
								while (true) {
									int xx = r.nextInt(3); // 무작위 수 하나 추출
									if (comBoard[xx] == null) { // 컴퓨터 필드 내 빈자리 유무 확인
										comBoard[xx] = comHand[tempC]; // 해당 빈자리에 카드 삽임
										break;
									}
									if (comBoard[0] != null || comBoard[1] != null || comBoard[2] != null) // 빈자리 없을 시
										comHand[tempC].error = 1; // 에러코드를 넣어 못쓰게 만듬
									break;
								}
								break;
							case "2": // 주문카드
								while (true) {
									switch (comHand[tempC].effect) {
									case "1":
										while (true) {
											int xx = r.nextInt(3);
											if (playerBoard[xx] != null) {
												playerBoard[xx].rDef -= comHand[tempC].effect_dmg;
												if (playerBoard[xx].rDef <= 0)
													playerBoard[xx] = null;
												break;
											}
											if (playerBoard[0] == null && playerBoard[1] == null
													&& playerBoard[2] == null) {
												playerHp -= comHand[tempC].effect_dmg;
												if (playerHp <= 0) {
													System.out.println("플레이어가 패배했습니다.");
													break loop_g;
												}
												break;
											}
										}
										break;
									case "2":
										while (true) {
											int xx = r.nextInt(3);
											if (comBoard[xx] != null) {
												comBoard[xx].rDef += comHand[tempC].effect_dmg;
												if (comBoard[xx].rDef > comBoard[xx].def)
													comBoard[xx].rDef = comBoard[xx].def;
												break;
											}
											if (comBoard[0] == null && comBoard[1] == null && comBoard[2] == null) {
												comHp += comHand[tempC].effect_dmg;
												if (comHp > 20)
													comHp = 20;
												break;
											}
										}
										break;
									case "3":
										for (int i = 0; i < 3; i++) {
											if (comBoard[i] == null)
												continue;
											comBoard[i].rAtt += comHand[tempC].effect_dmg;
										}
										break;
									}
									break;
								}
								comCost -= comHand[tempC].cost;
								break;
							}
						}
						boolean canUseCard = false;
						for (int i = 0; i < comBoard.length; i++) {
							if (comBoard[i] != null && comBoard[i].canAtt == true) {
								canUseCard = true;
								break;
							}
						}
						while (canUseCard) {
							int xx = r.nextInt(3);
							int yy = r.nextInt(3);
							if (comBoard[yy] != null && comBoard[yy].canAtt == true) {
								if (playerBoard[xx] != null) {
									playerBoard[xx].rDef -= comBoard[yy].rAtt;
									if (playerBoard[xx].rDef <= 0)
										playerBoard[xx] = null;
									comBoard[yy].canAtt = false;
								}
								if (playerBoard[0] == null && playerBoard[1] == null && playerBoard[2] == null) {
									playerHp -= comHand[yy].rAtt;
									comBoard[yy].canAtt = false;
									if (playerHp <= 0) {
										System.out.println("플레이어가 패배했습니다.");
										break loop_g;
									}
								}
							}
							if (comBoard[0] == null && comBoard[1] == null && comBoard[2] == null)
								canUseCard = false;
						}
					}

				}

				break;
			case "2":// 카드추가, 카드변경, 현재덱리스트 확인
				loop_c: while (true) {
					System.out.println("[1]카드 변경 / [2]덱리스트 / [e]초기화면으로");
					System.out.print("명령입력 : ");
					cmd = sc.next();
					Card newCard = null;
					switch (cmd) {
					case "1": // 새카드 직접 제작
						int nCardA = 0;
						int nCardD = 0;
						String nCardE = null;
						int nCardEd = 0;
						System.out.println("나만의 카드 제작/변경");
						System.out.print("카드이름 : ");
						String nCardN = sc.next();
						System.out.print("카드코스트 : ");
						int nCardC = Integer.parseInt(sc.next());
						System.out.print("카드타입([1]유닛카드/[2]주문카드) : ");
						String nCardT = sc.next();
						if (nCardT.equals("1")) {
							System.out.print("카드공력력 : ");
							nCardA = Integer.parseInt(sc.next());
							System.out.println("카드체력 : ");
							nCardD = Integer.parseInt(sc.next());
							newCard = new Card(nCardC, nCardN, nCardA, nCardD, "0", 0, nCardT);
						} else if (nCardT.equals("2")) {
							System.out.print("주문타입([1]적1개데미지 / [2]아군1개힐 / [3]아군전체효과 : ");
							nCardE = sc.next();
							System.out.println("주문공격력 : ");
							nCardEd = Integer.parseInt(sc.next());
							newCard = new Card(nCardC, nCardN, 0, 0, nCardE, nCardEd, nCardT);
						}
						System.out.println("🎛🎛🎛🎛🎛🎛제작된 카드🎛🎛🎛🎛🎛🎛");
						newCard.CardInfo();
						System.out.println("기존 카드와 변경하시겠습니까([1]YES / [2]NO) : ");
						String cmd2 = sc.next();
						switch (cmd2) { // 새카드 넣을 때 기본덱 안 카드와 교체 Alter
						// insert into card (c_no, c_cost, c_name, c_effect, c_effect_dmg, c_type)
						// value(22, 3, '화염구', 1, 4, 2);
						case "1":
							while (true) {
								System.out.println("변경하실 카드번호를 입력하세요 :");
								int editN = sc.nextInt();
								if (editN >= 1 && editN <= 30) {
									playerdeck.set(editN - 1, newCard);
									System.out.println("카드 변경완료"); // playerdeck ArrayList 안 카드만 수정 customizedcard 테이블에
																	// db반영
									switch (newCard.type) {
									case "1":
										dbExecuteUpdate(String.format(
												"update customizedcard set c_no=%d, c_cost=%d, c_name='%s', c_att=%d, c_def=%d, c_type=1 where c_no=%d",
												editN, nCardC, nCardN, nCardA, nCardD, editN));
										break;
									case "2":
										dbExecuteUpdate(String.format(
												"update customizedcard set c_no=%d, c_cost=%d, c_name='%s', c_effect=%d, c_effect_dmg=%d, c_type=2 where c_no=%d",
												editN, nCardC, nCardN, Integer.parseInt(nCardE), nCardEd, editN));
										break;
									}
									break;
								} else
									System.out.println("잘못된 입력입니다.");
							}
							break;
						case "2":
							System.out.println("제작된 카드는 삭제되었습니다.");
							break;
						}
						break;
					case "2": // 현재 DB에 저장되어있는 카드리스트 (기본덱 // 30장) 보여주기
						System.out.println("🃏🃏🃏🃏🃏🃏 저장된 카드 리스트 🃏🃏🃏🃏🃏🃏");
						for (int i = 0; i < playerdeck.size(); i++) {
							System.out.println("🎴🎴🎴🎴" + (i + 1) + "번카드 정보🎴🎴🎴🎴");
							Card tempC = playerdeck.get(i);
							tempC.CardInfo();
						}
						break;
					case "e":
						System.out.println("초기화면으로 돌아갑니다.");
						break loop_c;
					}
				}
				break;
			case "e":
				System.out.println("게임을 종료합니다.");
				break loop_m;
			}
		}
	};

	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("DB반영완료");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setDeck(String query, ArrayList<Card> c) {
		try {
			result = st.executeQuery("select * from " + query + " order by c_no");
			while (result.next()) {
				int cost = Integer.parseInt(result.getString("c_cost"));
				String name = result.getString("c_name");
				int att = Integer.parseInt(result.getString("c_att"));
				int def = Integer.parseInt(result.getString("c_def"));
				String effect = result.getString("c_effect");
				int effect_dmg = Integer.parseInt(result.getString("c_effect_dmg"));
				String type = result.getString("c_type");
				c.add(new Card(cost, name, att, def, effect, effect_dmg, type));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
