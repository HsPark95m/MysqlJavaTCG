package com.emma.tcg;

public class Main {
	public static void main(String[] args) {
		GameBoard g = new GameBoard();
		g.run();
	}
}
