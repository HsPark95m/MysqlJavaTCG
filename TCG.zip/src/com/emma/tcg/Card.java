package com.emma.tcg;

public class Card {
	int cost;
	String name;
	int att;
	int def;
	String effect;
	int effect_dmg;
	String type;
	public int rAtt;
	public int rDef;
	public int error;
	public boolean canAtt;

	public Card(int cost, String name, int att, int def, String effect, int effect_dmg, String type) {
		this.cost = cost;
		this.name = name;
		this.att = att;
		this.def = def;
		this.effect = effect;
		this.effect_dmg = effect_dmg;
		this.type = type;
		this.rAtt = att;
		this.rDef = def;
		this.error = 0;
		this.canAtt = false;
	}

	public void CardInfo() {
		System.out.println("코스트 : " + cost);
		System.out.println("카드이름 : " + name);
		switch (type) {
		case "1":
			System.out.println("공격력 : " + att);
			System.out.println("체력 : " + def);
			System.out.println("카드 타입 : 유닛카드");
			break;
		case "2":
			switch (effect) {
			case "1":
				System.out.println("카드 타입 : 주문카드");
				System.out.println("주문 타입 : 적 1개에 데미지");
				System.out.println("주문공격력 : " + effect_dmg);
				break;
			case "2":
				System.out.println("카드 타입 : 주문카드");
				System.out.println("주문 타입 : 아군 1개에 힐");
				System.out.println("힐량 : " + effect_dmg);
				break;
			case "3":
				System.out.println("카드 타입 : 주문카드");
				System.out.println("주문 타입 : 아군전체에 공격력 증가");
				System.out.println("증가량 : " + effect_dmg);
				break;
			}
			break;
		}
		System.out.println("====================");
	}
}
